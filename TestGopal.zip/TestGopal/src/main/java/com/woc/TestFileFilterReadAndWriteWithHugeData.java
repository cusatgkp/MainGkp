package com.woc;

import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.LineIterator;

public class TestFileFilterReadAndWriteWithHugeData {
    private static final String COMMA = ",";
    private static final String ENCODING = "UTF-8";
    private static int filterColumnIndex = -1;
    private static final String filterColumnName = "LifecycleStatus";
    private static final String LIVE = "LIVE";

    public static void main(String[] args) {
        System.out.println("welcome to Gopal Program");
        String inputFile = "src/main/resources/sample_input.csv";
        String outputFile = "/home/manendrakumar/Desktop/ttm/sample_output.csv";

        try (BufferedWriter writer = Files.newBufferedWriter(Paths.get(outputFile))){
            LineIterator it = FileUtils.lineIterator(new File(inputFile), ENCODING);
            while (it.hasNext()) {
                String line = it.nextLine();
                if(null == line){
                    continue;
                }

                String[] row = line.split(COMMA);
                if(-1 == filterColumnIndex) {
                    populateTheFilterColumnIndex(row);
                    continue;
                }
                if(LIVE.equals(nullsafeTrim(row[filterColumnIndex]))){
                    writer.write(line);
                    writer.newLine();
                    System.out.println(line);
                }

            }
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    private static void populateTheFilterColumnIndex(String[] row) {
        int colIndex = 0;
        for (String colData : row) {
            if (filterColumnName.equals(nullsafeTrim(colData))) {
                filterColumnIndex = colIndex;
                break;
            }
            colIndex++;
        }
    }

    private static String nullsafeTrim(String col) {
        return (null == col) ? null : col.trim();
    }
}
